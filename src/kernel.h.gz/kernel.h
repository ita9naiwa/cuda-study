#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <math.h>
#include <common.h>


float vec_sum(float *a, float *b, float *r, int n);
float mat_sum(float *a, float *b, float *r, int m, int n);
float mat_mul(float *a, float *b, float *r, int m, int k, int n);
void __run();
