float cu_kmeans(float *vecs, int n, int d, int K, int iter,
                float *o_centroids, int *o_belonging);